package com.example.multiaichat.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.multiaichat.ui.theme.AppTheme
import com.example.multiaichat.security.CredentialStore

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    var openAiKey by remember { mutableStateOf(CredentialStore.getApiKey("openai") ?: "") }
    var anthropicKey by remember { mutableStateOf(CredentialStore.getApiKey("anthropic") ?: "") }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Enter your API keys (kept encrypted on device)." )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(value = openAiKey, onValueChange = { openAiKey = it }, label = { Text("OpenAI API Key") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = anthropicKey, onValueChange = { anthropicKey = it }, label = { Text("Anthropic API Key") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (openAiKey.isNotBlank()) CredentialStore.setApiKey("openai", openAiKey)
            if (anthropicKey.isNotBlank()) CredentialStore.setApiKey("anthropic", anthropicKey)
        }) {
            Text("Save Keys")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Warning: embedding provider keys in the client may violate provider or store policies. Prefer server proxy for production.") 
    }
}
