package com.example.multiaichat.ui.theme

import androidx.compose.material.MaterialTheme
import androidx.compose.material.darkColors
import androidx.compose.material.lightColors
import androidx.compose.runtime.Composable

private val LightColorPalette = lightColors(
    primary = androidx.compose.ui.graphics.Color(0xFF0B63FF),
    primaryVariant = androidx.compose.ui.graphics.Color(0xFF084ED6),
    secondary = androidx.compose.ui.graphics.Color(0xFF6C7A89),
    background = androidx.compose.ui.graphics.Color(0xFFF7F9FC),
    surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colors = LightColorPalette,
        typography = androidx.compose.material.Typography(),
        shapes = androidx.compose.material.Shapes(),
        content = content
    )
}
