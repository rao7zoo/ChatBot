package com.example.multiaichat.network

import com.example.multiaichat.data.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import com.google.gson.Gson
import com.example.multiaichat.security.CredentialStore

class OpenAIProvider : AiProvider {
    private val client = OkHttpClient()
    private val gson = Gson()
    private val apiKeyFallback: String = BuildConfig.OPENAI_API_KEY

    override suspend fun sendChat(history: List<Message>): String? = withContext(Dispatchers.IO) {
        val url = "https://api.openai.com/v1/chat/completions"
        val messages = history.map { mapOf("role" to it.role, "content" to it.content) }
        val bodyJson = mapOf(
            "model" to "gpt-4o-mini",
            "messages" to messages,
            "max_tokens" to 500
        )
        val bodyString = gson.toJson(bodyJson)
        val request = Request.Builder()
            .url(url)
            .post(bodyString.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer ${getApiKey()}")
            .build()

        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("OpenAI error: ${resp.code} - ${resp.message}")
            val respBody = resp.body?.string() ?: return@withContext null
            val map = gson.fromJson(respBody, Map::class.java)
            val choices = map["choices"] as? List<*>
            val first = choices?.firstOrNull() as? Map<*, *>
            val msg = (first?.get("message") as? Map<*, *>)?.get("content") as? String
            return@withContext msg
        }
    }

    private fun getApiKey(): String {
        val k = CredentialStore.getApiKey("openai")
        return if (!k.isNullOrBlank()) k else apiKeyFallback
    }
}
