package com.example.multiaichat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.multiaichat.ui.theme.AppTheme
import com.example.multiaichat.ui.ChatScreen
import com.example.multiaichat.data.ChatViewModel
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                ChatScreen(viewModel = vm)
            }
        }
    }
}
