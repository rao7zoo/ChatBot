package com.example.multiaichat.network

import com.example.multiaichat.data.Message

interface AiProvider {
    suspend fun sendChat(history: List<Message>): String?
}

data class ProviderInfo(val id: String, val displayName: String)

object ProviderRegistry {
    val providers = listOf(
        ProviderInfo("openai", "OpenAI (ChatGPT)"),
        ProviderInfo("anthropic", "Anthropic")
    )

    private val implementations = mutableMapOf<String, AiProvider>()

    init {
        implementations["openai"] = OpenAIProvider()
        implementations["anthropic"] = AnthropicProvider()
    }

    fun getProvider(id: String): AiProvider? = implementations[id]
}
