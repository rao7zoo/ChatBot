package com.example.multiaichat.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.ui.platform.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import com.example.multiaichat.MainActivity
import kotlinx.coroutines.delay

class SplashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Display a Compose splash screen then navigate to MainActivity
        setContent {
            androidx.compose.material.Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.primary) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(id = com.example.multiaichat.R.drawable.ic_logo),
                            contentDescription = "logo",
                            modifier = Modifier.size(160.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Multi AI Chat", color = MaterialTheme.colors.onPrimary, fontSize = 20.sp)
                    }
                }
            }
            LaunchedEffect(Unit) {
                delay(900) // short splash
                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                finish()
            }
        }
    }
}
