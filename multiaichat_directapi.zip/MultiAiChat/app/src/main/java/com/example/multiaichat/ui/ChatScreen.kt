package com.example.multiaichat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.multiaichat.data.ChatViewModel
import com.example.multiaichat.data.Message
import androidx.compose.ui.text.style.TextOverflow

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var text by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Multi AI Chat") },
                actions = {
                    Text(text = uiState.selectedProvider.displayName, modifier = Modifier.padding(8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            )
        },
        content = { padding ->
            Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                // Provider selector + header
                ProviderSelectorRow(selected = uiState.selectedProvider, onSelect = { viewModel.selectProvider(it) })

                Divider(modifier = Modifier.padding(vertical = 6.dp))

                LazyColumn(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    items(uiState.messages) { msg ->
                        MessageRow(message = msg)
                    }
                }

                if (uiState.isLoading) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Type a message...") })
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = {
                        if (text.isNotBlank()) {
                            viewModel.sendMessage(text)
                            text = ""
                        }
                    }) {
                        Text("Send")
                    }
                }
            }
        }
    )
}

@Composable
fun ProviderSelectorRow(selected: com.example.multiaichat.network.ProviderInfo, onSelect: (com.example.multiaichat.network.ProviderInfo) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text = "Provider:", modifier = Modifier.padding(end = 8.dp))
        DropdownMenuSelector(selected, onSelect)
    }
}
