package com.example.multiaichat.data

data class Message(
    val id: Long = System.currentTimeMillis(),
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class UiState(
    val messages: List<Message> = emptyList(),
    val isLoading: Boolean = false,
    val selectedProvider: com.example.multiaichat.network.ProviderInfo = com.example.multiaichat.network.ProviderRegistry.providers.first()
)
