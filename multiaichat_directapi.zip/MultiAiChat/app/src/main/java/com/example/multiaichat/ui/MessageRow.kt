package com.example.multiaichat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.multiaichat.data.Message
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape

@Composable
fun MessageRow(message: Message) {
    val isUser = message.role == "user"
    Row(modifier = Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        val bubbleColor = if (isUser) MaterialTheme.colors.primary else MaterialTheme.colors.surface
        val textColor = if (isUser) Color.White else Color.Black
        Box(modifier = Modifier
            .widthIn(max = 320.dp)
            .background(bubbleColor, shape = RoundedCornerShape(12.dp))
            .padding(10.dp)) {
            Text(text = message.content, color = textColor)
        }
    }
}
