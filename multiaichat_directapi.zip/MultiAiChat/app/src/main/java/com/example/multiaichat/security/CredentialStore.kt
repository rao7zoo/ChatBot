package com.example.multiaichat.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object CredentialStore {
    private const val PREFS_NAME = "ai_keys_prefs"
    private lateinit var appContext: Context

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun prefs(): EncryptedSharedPreferences {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            appContext,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun setApiKey(providerId: String, apiKey: String) {
        val p = prefs()
        p.edit().putString("key_\$providerId", apiKey).apply()
    }

    fun getApiKey(providerId: String): String? {
        val p = prefs()
        return p.getString("key_\$providerId", null)
    }

    fun clearApiKey(providerId: String) {
        val p = prefs()
        p.edit().remove("key_\$providerId").apply()
    }
}
