package com.example.multiaichat

import android.app.Application
import com.example.multiaichat.security.CredentialStore

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CredentialStore.init(this)
    }
}
