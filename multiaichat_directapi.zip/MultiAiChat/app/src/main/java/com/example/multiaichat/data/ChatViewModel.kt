package com.example.multiaichat.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.multiaichat.network.ProviderRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val history = mutableListOf<Message>()

    fun selectProvider(info: com.example.multiaichat.network.ProviderInfo) {
        _uiState.value = _uiState.value.copy(selectedProvider = info)
    }

    fun sendMessage(text: String) {
        val userMsg = Message(role = "user", content = text)
        addToHistory(userMsg)

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            try {
                val provider = ProviderRegistry.getProvider(_uiState.value.selectedProvider.id)
                val assistant = provider?.sendChat(history.map { it })
                if (assistant != null) {
                    addToHistory(Message(role = "assistant", content = assistant))
                } else {
                    addToHistory(Message(role = "assistant", content = "(No response)"))
                }
            } catch (e: Exception) {
                addToHistory(Message(role = "assistant", content = "Error: ${e.localizedMessage}"))
            } finally {
                _uiState.value = _uiState.value.copy(isLoading = false)
            }
        }
    }

    private fun addToHistory(msg: Message) {
        history.add(msg)
        _uiState.value = _uiState.value.copy(messages = history.toList())
    }
}
