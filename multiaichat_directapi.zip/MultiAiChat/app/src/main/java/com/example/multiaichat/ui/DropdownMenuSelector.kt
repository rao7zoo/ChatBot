package com.example.multiaichat.ui

import androidx.compose.material.*
import androidx.compose.runtime.*
import com.example.multiaichat.network.ProviderRegistry
import com.example.multiaichat.network.ProviderInfo

@Composable
fun DropdownMenuSelector(selectedProvider: ProviderInfo, onSelect: (ProviderInfo) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        TextButton(onClick = { expanded = true }) {
            Text(selectedProvider.displayName)
        }
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            ProviderRegistry.providers.forEach { p ->
                DropdownMenuItem(onClick = { expanded = false; onSelect(p) }) {
                    Text(p.displayName)
                }
            }
        }
    }
}
