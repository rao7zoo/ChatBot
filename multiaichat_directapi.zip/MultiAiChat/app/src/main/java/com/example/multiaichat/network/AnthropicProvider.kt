package com.example.multiaichat.network

import com.example.multiaichat.data.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import com.google.gson.Gson
import com.example.multiaichat.security.CredentialStore

class AnthropicProvider : AiProvider {
    private val client = OkHttpClient()
    private val gson = Gson()
    private val apiKeyFallback: String = BuildConfig.ANTHROPIC_API_KEY

    override suspend fun sendChat(history: List<Message>): String? = withContext(Dispatchers.IO) {
        val url = "https://api.anthropic.com/v1/complete"
        val prompt = history.joinToString(separator = "\n") { "${it.role.uppercase()}: ${it.content}" } + "\nASSISTANT:"
        val bodyJson = mapOf(
            "model" to "claude-v1",
            "prompt" to prompt,
            "max_tokens" to 500
        )
        val bodyString = gson.toJson(bodyJson)
        val request = Request.Builder()
            .url(url)
            .post(bodyString.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer $apiKey")
            .build()

        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("Anthropic error: ${resp.code} - ${resp.message}")
            val respBody = resp.body?.string() ?: return@withContext null
            val map = gson.fromJson(respBody, Map::class.java)
            val completion = map["completion"] as? String
            return@withContext completion
        }
    }

    private fun getApiKey(): String {
        val k = CredentialStore.getApiKey("anthropic")
        return if (!k.isNullOrBlank()) k else apiKeyFallback
    }
}
