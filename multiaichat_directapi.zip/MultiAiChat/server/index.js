require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(helmet());
app.use(express.json());

// Basic CORS setup (override in production)
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s=>s.trim()).filter(Boolean);
app.use(cors({
    origin: function(origin, callback) {
        if (!origin) return callback(null, true);
        if (allowed.length === 0 || allowed.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    }
}));

// Rate limiting - adjust as needed
const limiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute window
    max: 30, // limit each IP to 30 requests per windowMs
});
app.use(limiter);

// Simple health
app.get('/health', (req, res) => res.json({status: 'ok'}));

/**
 * POST /api/openai
 * Body: { messages: [ { role, content }, ... ], model?, max_tokens? }
 * Forwards to OpenAI Chat Completions endpoint.
 */
app.post('/api/openai', async (req, res) => {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'Server missing OpenAI API key' });

    const payload = {
        model: req.body.model || 'gpt-4o-mini',
        messages: req.body.messages || [],
        max_tokens: req.body.max_tokens || 500
    };

    try {
        const r = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify(payload)
        });
        const data = await r.json();
        res.status(r.status).json(data);
    } catch (err) {
        console.error('OpenAI proxy error', err);
        res.status(502).json({ error: 'Bad gateway', details: String(err) });
    }
});

/**
 * POST /api/anthropic
 * Body: { prompt, model?, max_tokens? }
 * Forwards to Anthropic complete endpoint.
 */
app.post('/api/anthropic', async (req, res) => {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'Server missing Anthropic API key' });

    const payload = {
        model: req.body.model || 'claude-v1',
        prompt: req.body.prompt || '',
        max_tokens: req.body.max_tokens || 500
    };

    try {
        const r = await fetch('https://api.anthropic.com/v1/complete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey
            },
            body: JSON.stringify(payload)
        });
        const data = await r.json();
        res.status(r.status).json(data);
    } catch (err) {
        console.error('Anthropic proxy error', err);
        res.status(502).json({ error: 'Bad gateway', details: String(err) });
    }
});

// Serve simple privacy policy page and static (for demo)
app.use(express.static('public'));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Proxy server listening on port ${PORT}`));
